﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class calc : Form
    {
        public calc()
        {
            InitializeComponent();
        }

        private void calc_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txt1.Text);
            int n2 = int.Parse(txt2.Text);
            switch (comb.SelectedIndex)
            {
                case 0:
                    int result = n1 + n2;
                    txt3.Text = result.ToString();
                    break;
                case 1:
                    int result1 = n1 - n2;
                    txt3.Text = result1.ToString();
                    break;
                case 2:
                    int result2 = n1 * n2;
                    txt3.Text = result2.ToString();
                    break;
                case 3:
                    int result3 = n1 / n2;
                    txt3.Text = result3.ToString();
                    break;
                default:
                    MessageBox.Show("Invalid");
                    break;

            }
        }
    }
}
