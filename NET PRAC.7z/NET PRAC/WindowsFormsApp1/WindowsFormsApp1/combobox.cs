﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class combobox : Form
    {
        public combobox()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // MessageBox.Show(cmb1.SelectedItem.ToString());
           switch(cmb1.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("car");
                    break;
                case 1:
                    MessageBox.Show("bike");
                    break;
                case 2:
                    MessageBox.Show("truck");
                    break;
                default:
                    MessageBox.Show("Invalid");
                    break;
                     
            }
        }
    }
}
