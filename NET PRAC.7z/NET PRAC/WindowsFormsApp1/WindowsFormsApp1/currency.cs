﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
namespace WindowsFormsApp1
{
    public partial class currency : Form
    {
        public currency()
        {
            InitializeComponent();
        }

        private void currency_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(textBox1.Text);
            switch(combo.SelectedIndex)
            {
                case 0:
                    double res = n1 * 0.014;
                    textBox2.Text = res.ToString();
                    break;
                case 1:
                    double res1 = n1 * 73.62;
                    textBox2.Text = res1.ToString();
                    break;

            }
        }

        private void combo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            combo.Text = "Choose";
            textBox2.Text = "";

        }
    }
    }

