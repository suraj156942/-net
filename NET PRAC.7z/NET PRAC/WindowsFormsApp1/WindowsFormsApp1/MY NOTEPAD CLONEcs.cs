﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApp1
{
    public partial class MY_NOTEPAD_CLONEcs : Form
    {
        public MY_NOTEPAD_CLONEcs()
        {
            InitializeComponent();
        }

        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Made by RB SOLUTION DEVELOPER in 2021", "Caption", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void oPENToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "only text file(*.txt)|*.txt";
            // ofd.ShowDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string ourfilename = ofd.FileName.ToString();
                //  MessageBox.Show(ourfilename);
                string myfile = File.ReadAllText(ourfilename);
                rtb1.Text = myfile;
            }
        }

        private void nEWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb1.Clear();
        }

        private void sAVEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.DefaultExt = ".txt";
            saveFileDialog1.Filter = "Text File|*.txt|PDF file|*.pdf|Word File|*.doc";
            DialogResult dr = saveFileDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog1.FileName, rtb1.Text);
            }
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb1.Cut();
        }

        private void cOPYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb1.Copy();
        }

        private void pASTEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb1.Paste();
        }

        private void rEDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb1.Redo();
        }

        private void uNDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb1.Undo();
        }

        private void fONTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(fontDialog1.ShowDialog()==DialogResult.OK)
            {
                rtb1.Font = fontDialog1.Font;
            }
        }
    }
}