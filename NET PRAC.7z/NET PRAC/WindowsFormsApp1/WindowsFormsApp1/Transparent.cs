﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Transparent : Form
    {
        public Transparent()
        {
            InitializeComponent();
            toolTip1.SetToolTip(btnClick, "click me");
        }

        private void Transparent_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(" form is loading");
        }

        private void Hover(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to do this?", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                MessageBox.Show("You pressed OK!");
            }
            else
            {
                //MessageBox.Show("You pressed Cancel!");
                Application.Exit();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void click(object sender, EventArgs e)
        {
            btnClick.Text = "button changed";
        }

        private void btnrun_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Increment(2);
            if(progressBar1.Value>=100)
            {
                progressBar1.Value = 0;
                timer1.Stop();
            }
        }

        private void btnDate_Click(object sender, EventArgs e)
        {
            MessageBox.Show(dateTimePicker1.Value.ToString());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnFont_Click(object sender, EventArgs e)
        {
           DialogResult d = fontDialog1.ShowDialog();
            if (d == DialogResult.OK)
            {
                label1.Font = fontDialog1.Font;
            }
        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {
            label1.Font = fontDialog1.Font;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            DialogResult d = colorDialog1.ShowDialog();
            if (d == DialogResult.OK)
            {
                this.BackColor = colorDialog1.Color;
            }
        }
    }
}
