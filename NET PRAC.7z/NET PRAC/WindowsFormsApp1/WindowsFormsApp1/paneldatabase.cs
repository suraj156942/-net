﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class paneldatabase : Form
    {
        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        public paneldatabase()
        {
            InitializeComponent();
            //changecursor();
        }

        private void tbox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void paneldatabase_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string insertQuery = "insert into test_db.user(id,name,age)values('"+tbox1.Text+ "','" + tbox2.Text + "','" + tbox3.Text + "')";
            connection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, connection);
            if(command.ExecuteNonQuery()==1)
            {
                MessageBox.Show("data is inserted");

            }
            else
            {
                MessageBox.Show("NOT INSERTED");
            }
        }
    }
}
