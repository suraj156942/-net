﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label1.Text = "Hello world";
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            label1.Text = "Hello world again again......";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            label1.Text = "text has been cancelled";
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();

            Loginfrm lfrm = new Loginfrm();
            lfrm.Show();
        }
    }
}
