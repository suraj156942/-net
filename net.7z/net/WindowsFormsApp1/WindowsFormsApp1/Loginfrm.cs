﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Loginfrm : Form
    {
        public Loginfrm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Hide();
            login();

           
        }
        private void login()
        {
            string id = rTbUserId.Text;
            string pass = rTbPass.Text;
            if (id == "abc" && pass == "123456")
            {
                this.Hide();
                Form3 f3 = new Form3();
                f3.Show();
            }
            else
            {
                MessageBox.Show("something went wrong");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            reset();
        }
        private void reset()
        {
            rTbUserId.Text = "";
            rTbPass.Text = "";
        }
        private void rTbPass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==(char)Keys.Enter)
            {
                login();
            }
            if (e.KeyChar ==(char)Keys.F1)
            {
                reset();
            }
        }
    }
}
