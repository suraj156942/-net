﻿namespace WindowsFormsApp1
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtbox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbox2 = new System.Windows.Forms.TextBox();
            this.txtbox3 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkSms = new System.Windows.Forms.CheckBox();
            this.chkReport = new System.Windows.Forms.CheckBox();
            this.chkTransection = new System.Windows.Forms.CheckBox();
            this.lblSmsMSg = new System.Windows.Forms.Label();
            this.lblTran = new System.Windows.Forms.Label();
            this.btnSingnup = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "First name:";
            // 
            // txtbox1
            // 
            this.txtbox1.Location = new System.Drawing.Point(177, 54);
            this.txtbox1.Name = "txtbox1";
            this.txtbox1.Size = new System.Drawing.Size(334, 20);
            this.txtbox1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(57, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Last name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(57, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Email:";
            // 
            // txtbox2
            // 
            this.txtbox2.Location = new System.Drawing.Point(177, 87);
            this.txtbox2.Name = "txtbox2";
            this.txtbox2.Size = new System.Drawing.Size(334, 20);
            this.txtbox2.TabIndex = 3;
            // 
            // txtbox3
            // 
            this.txtbox3.Location = new System.Drawing.Point(177, 119);
            this.txtbox3.Name = "txtbox3";
            this.txtbox3.Size = new System.Drawing.Size(334, 20);
            this.txtbox3.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblTran);
            this.groupBox1.Controls.Add(this.lblSmsMSg);
            this.groupBox1.Controls.Add(this.chkTransection);
            this.groupBox1.Controls.Add(this.chkReport);
            this.groupBox1.Controls.Add(this.chkSms);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(44, 184);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(560, 130);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Services";
            // 
            // chkSms
            // 
            this.chkSms.AutoSize = true;
            this.chkSms.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSms.Location = new System.Drawing.Point(153, 26);
            this.chkSms.Name = "chkSms";
            this.chkSms.Size = new System.Drawing.Size(159, 22);
            this.chkSms.TabIndex = 5;
            this.chkSms.Text = "SMS Notificatiom";
            this.chkSms.UseVisualStyleBackColor = true;
            this.chkSms.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chkReport
            // 
            this.chkReport.AutoSize = true;
            this.chkReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReport.Location = new System.Drawing.Point(153, 54);
            this.chkReport.Name = "chkReport";
            this.chkReport.Size = new System.Drawing.Size(87, 22);
            this.chkReport.TabIndex = 6;
            this.chkReport.Text = "Reports";
            this.chkReport.UseVisualStyleBackColor = true;
            this.chkReport.CheckedChanged += new System.EventHandler(this.chkReport_CheckedChanged);
            // 
            // chkTransection
            // 
            this.chkTransection.AutoSize = true;
            this.chkTransection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTransection.Location = new System.Drawing.Point(153, 82);
            this.chkTransection.Name = "chkTransection";
            this.chkTransection.Size = new System.Drawing.Size(181, 22);
            this.chkTransection.TabIndex = 7;
            this.chkTransection.Text = "Transection Reports";
            this.chkTransection.UseVisualStyleBackColor = true;
            this.chkTransection.CheckedChanged += new System.EventHandler(this.chkTransection_CheckedChanged);
            // 
            // lblSmsMSg
            // 
            this.lblSmsMSg.AutoSize = true;
            this.lblSmsMSg.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSmsMSg.Location = new System.Drawing.Point(358, 26);
            this.lblSmsMSg.Name = "lblSmsMSg";
            this.lblSmsMSg.Size = new System.Drawing.Size(66, 24);
            this.lblSmsMSg.TabIndex = 5;
            this.lblSmsMSg.Text = "--------";
            // 
            // lblTran
            // 
            this.lblTran.AutoSize = true;
            this.lblTran.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTran.Location = new System.Drawing.Point(358, 82);
            this.lblTran.Name = "lblTran";
            this.lblTran.Size = new System.Drawing.Size(66, 24);
            this.lblTran.TabIndex = 6;
            this.lblTran.Text = "--------";
            // 
            // btnSingnup
            // 
            this.btnSingnup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingnup.Location = new System.Drawing.Point(529, 344);
            this.btnSingnup.Name = "btnSingnup";
            this.btnSingnup.Size = new System.Drawing.Size(75, 42);
            this.btnSingnup.TabIndex = 8;
            this.btnSingnup.Text = "Sign Up";
            this.btnSingnup.UseVisualStyleBackColor = true;
            this.btnSingnup.Click += new System.EventHandler(this.btnSingnup_Click);
            // 
            // Signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 398);
            this.Controls.Add(this.btnSingnup);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtbox3);
            this.Controls.Add(this.txtbox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtbox1);
            this.Controls.Add(this.label1);
            this.Name = "Signup";
            this.Text = "Signup";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbox2;
        private System.Windows.Forms.TextBox txtbox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkTransection;
        private System.Windows.Forms.CheckBox chkReport;
        private System.Windows.Forms.CheckBox chkSms;
        private System.Windows.Forms.Label lblTran;
        private System.Windows.Forms.Label lblSmsMSg;
        private System.Windows.Forms.Button btnSingnup;
    }
}