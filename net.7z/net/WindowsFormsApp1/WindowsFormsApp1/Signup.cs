﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Signup : Form
    {
        public static string fname;
        public static string lname;
        public static string email;
        public static Boolean sms;
        public static Boolean report;
        public static Boolean transection;
        public Signup()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(chkSms.Checked)
            {
                sms = true;
                lblSmsMSg.Text = "services charge is apply";
            }
            else
            {
                sms = false;
                lblSmsMSg.Text = "-----------";
            }
        }

        private void chkTransection_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnSingnup_Click(object sender, EventArgs e)
        {

        }

        private void chkReport_CheckedChanged(object sender, EventArgs e)
        {
            if (chkReport.Checked)
            {
                report = true;
                lblSmsMSg.Text = "services charge is apply";
            }
            else
            {
                sms = false;
                lblSmsMSg.Text = "-----------";
            }
        }
    }
}
